Thank you for using the Explorer Suite,

this is a free software and so it is given without warranties, this means the use of this tool is at your own risk. I take no responsilbity for any damage that may unintentionally be caused through its use.

If you find a bug or you want to send me a comment: ntcore@gmail.com

Daniel Pistelli